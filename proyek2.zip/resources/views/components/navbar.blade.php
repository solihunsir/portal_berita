<nav class="bg-gray-800" x-data="{ isOpen: false }">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex h-16 items-center justify-between">
            <div class="flex items-center">
                <div class="hidden md:block">
                    <!-- Navbar kategori yang dapat digulir secara horizontal -->
                    <div class="ml-10 flex items-baseline space-x-4 overflow-x-auto whitespace-nowrap">
                        <!-- Loop through categories -->
                        @foreach (App\Models\Category::all() as $category)
                            <x-nav-link href="/posts?category={{ $category->slug }}" :active="request()->is('posts?category=' . $category->slug)">
                                {{ $category->name }}
                            </x-nav-link>
                        @endforeach
                    </div>
                </div>
            </div>
            <!-- Hamburger Icon for Mobile -->
            <div class="-mr-2 flex md:hidden">
                <button @click="isOpen = !isOpen" class="text-white">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile menu, show/hide based on menu state -->
    <div x-show="isOpen" class="md:hidden" id="mobile-menu">
        <div class="space-y-1 px-2 pt-2 pb-3 sm:px-3 overflow-x-auto whitespace-nowrap">
            <!-- Mobile category links -->
            @foreach (App\Models\Category::all() as $category)
                <x-nav-link href="/posts?category={{ $category->slug }}" :active="request()->is('posts?category=' . $category->slug)">
                    {{ $category->name }}
                </x-nav-link>
            @endforeach
        </div>
    </div>
</nav>
