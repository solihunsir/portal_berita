<!DOCTYPE html>
<html>

<head>
    <title>Edit Berita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <h2>Edit Berita</h2>
        <form action="/dashboard/update/{{ $post->id }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label>Judul</label>
                <input type="text" name="title" class="form-control" value="{{ $post->title }}" required>
            </div>
            <div class="mb-3">
                <label>Slug</label>
                <input type="text" name="slug" class="form-control" value="{{ $post->slug }}" required>
            </div>
            <div class="mb-3">
                <label>Isi</label>
                <textarea name="body" class="form-control" rows="5" required>{{ $post->body }}</textarea>
            </div>
            <div class="mb-3">
                <label>Author</label>
                <select name="author_id" class="form-control" required>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $post->author_id == $user->id ? 'selected' : '' }}>
                            {{ $user->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label>Kategori</label>
                <select name="category_id" class="form-control" required>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ $post->category_id == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label>Gambar Saat Ini:</label><br>
                @if ($post->image)
                    <img src="{{ asset('storage/' . $post->image) }}" width="150" class="mb-2">
                @else
                    <p><i>Tidak ada gambar</i></p>
                @endif
                <input type="file" name="image" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="/dashboard" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>

</html>
