<!DOCTYPE html>
<html>

<head>
    <title>Dashboard Berita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <h2>Dashboard Berita</h2>

        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <a href="/dashboard/create" class="btn btn-primary mb-3">+ Tambah Berita</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Judul</th>
                    <th>Slug</th>
                    <th>Isi</th>
                    <th>Author</th>
                    <th>Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($posts as $post)
                    <tr>
                        <td>
                            @if ($post->image)
                                <img src="{{ asset('storage/' . $post->image) }}" width="100">
                            @else
                                -
                            @endif
                        </td>
                        <td>{{ $post->title }}</td>
                        <td>{{ $post->slug }}</td>
                        <td>{{ \Illuminate\Support\Str::limit($post->body, 100) }}</td>
                        <td>{{ $post->author->name ?? '-' }}</td>
                        <td>{{ $post->category->name ?? '-' }}</td>
                        <td>
                            <a href="/dashboard/edit/{{ $post->id }}" class="btn btn-sm btn-warning">Edit</a>
                            <a href="/dashboard/delete/{{ $post->id }}" onclick="return confirm('Yakin hapus?')"
                                class="btn btn-sm btn-danger">Hapus</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>
