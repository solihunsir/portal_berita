<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    <h3>Ini adalah Halaman About</h3>
  </x-layout> 