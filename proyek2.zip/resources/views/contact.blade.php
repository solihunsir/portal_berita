<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    <h3>Ini adalah Halaman Contact</h3>
  </x-layout>