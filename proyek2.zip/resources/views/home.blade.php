<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>

    <!-- Hero Section -->
    <section class="hero-section bg-gradient-to-r from-blue-600 to-indigo-800 text-white py-20">
        <div class="container mx-auto px-8">
            <div class="grid md:grid-cols-2 gap-8 items-center">
                <div class="hero-content">
                    <h1 class="text-4xl md:text-5xl font-bold mb-4">Selamat Datang di Website Kami</h1>
                    <p class="text-xl mb-8">Solusi terbaik untuk kebutuhan digital Anda dengan layanan profesional dan
                        berkualitas tinggi.</p>
                    <div class="flex flex-wrap gap-4">
                        <a href="/about"
                            class="bg-white text-indigo-700 hover:bg-indigo-50 font-semibold py-3 px-6 rounded-lg transition duration-300">Tentang
                            Kami</a>
                        <a href="/kontak"
                            class="bg-transparent border-2 border-white hover:bg-white hover:text-indigo-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300">Hubungi
                            Kami</a>
                    </div>
                </div>
                <div class="hero-image hidden md:block">
                    <img src="images/winni.png" alt="Hero Image" class="w-full h-auto">
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    {{-- <section class="features-section py-16 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Layanan Unggulan Kami</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">Kami menawarkan berbagai layanan terbaik untuk memenuhi
                    kebutuhan Anda</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="feature-card bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300">
                    <div class="icon-wrapper mb-4 text-indigo-600">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Web Development</h3>
                    <p class="text-gray-600">Kami membuat website yang responsif dan modern untuk bisnis Anda.</p>
                </div>
                <div class="feature-card bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300">
                    <div class="icon-wrapper mb-4 text-indigo-600">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Mobile App</h3>
                    <p class="text-gray-600">Aplikasi mobile yang intuitif dan mudah digunakan untuk platform iOS dan
                        Android.</p>
                </div>
                <div class="feature-card bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300">
                    <div class="icon-wrapper mb-4 text-indigo-600">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Digital Marketing</h3>
                    <p class="text-gray-600">Strategi pemasaran digital yang efektif untuk meningkatkan brand awareness.
                    </p>
                </div>
            </div>
        </div>
    </section> --}}

    <section class="testimonials-section py-16 bg-indigo-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Apa Kata Klien Kami</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">Lihat pengalaman dan testimoni dari klien yang telah bekerja
                    sama dengan kami</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="testimonial-card bg-white p-6 rounded-lg shadow-md">

                    <p class="text-gray-600 mb-4">"Sangat puas dengan layanan yang diberikan. Website kami sekarang
                        tampil lebih profesional dan modern. Tim support juga sangat responsif."</p>
                    <div class="testimonial-author flex items-center">

                        <div>
                            <h4 class="font-semibold text-gray-800">Budi Santoso</h4>
                            <p class="text-sm text-gray-500">Bg...</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card bg-white p-6 rounded-lg shadow-md">

                    <p class="text-gray-600 mb-4">"Proses pengembangan aplikasi mobile berjalan lancar dan tepat waktu.
                        Fitur-fitur yang diimplementasikan sesuai dengan kebutuhan bisnis kami."</p>
                    <div class="testimonial-author flex items-center">

                        <div>
                            <h4 class="font-semibold text-gray-800">Dewi Anggraini</h4>
                            <p class="text-sm text-gray-500">Bg...</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card bg-white p-6 rounded-lg shadow-md">

                    <p class="text-gray-600 mb-4">"Strategi digital marketing yang diberikan sangat efektif. Traffic
                        website meningkat dan konversi penjualan naik signifikan dalam waktu singkat."</p>
                    <div class="testimonial-author flex items-center">

                        <div>
                            <h4 class="font-semibold text-gray-800">Rudi Hermawan</h4>
                            <p class="text-sm text-gray-500">Bg...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section py-16 bg-indigo-700 text-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">Siap Untuk Memulai Proyek Anda?</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Hubungi kami sekarang untuk konsultasi gratis dan dapatkan
                penawaran terbaik untuk kebutuhan digital Anda</p>
            <a href="/kontak"
                class="bg-white text-indigo-700 hover:bg-indigo-50 font-semibold py-3 px-8 rounded-lg text-lg transition duration-300 inline-block">Hubungi
                Kami</a>
        </div>
    </section>
</x-layout>
