<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Category::create([
            'name' => 'Web Design',
            'slug' => 'web-design',
            'color' => 'blue'
        ]);

        Category::create([
            'name' => 'Pemrogramman',
            'slug' => 'pemrograman',
            'color' => 'green'
        ]);

        Category::create([
            'name' => 'UI UX',
            'slug' => 'ui-ux',
            'color' => 'red'
        ]);

        Category::create([
            'name' => 'Sistem Analis',
            'slug' => 'sistem-analis',
            'color' => 'yellow'
        ]);

        Category::create([
            'name' => 'Desain Grafis',
            'slug' => 'desain-grafis',
            'color' => 'purple'
        ]);

        Category::create([
            'name' => 'Jaringan Komputer',
            'slug' => 'jaringan-komputer',
            'color' => 'orange'
        ]);

        Category::create([
            'name' => 'Keamanan Jaringan',
            'slug' => 'keamanan-jaringan',
            'color' => 'pink'
        ]);

        Category::create([
            'name' => 'Manajemen Proyek',
            'slug' => 'manajemen-proyek',
            'color' => 'teal'
        ]);

        Category::create([
            'name' => 'Artificial Intelligence',
            'slug' => 'artificial-intelligence',
            'color' => 'brown'
        ]);

        Category::create([
            'name' => 'Data Science',
            'slug' => 'data-science',
            'color' => 'grey'
        ]);

        Category::create([
            'name' => 'Cloud Computing',
            'slug' => 'cloud-computing',
            'color' => 'indigo'
        ]);

        Category::create([
            'name' => 'Mobile Development',
            'slug' => 'mobile-development',
            'color' => 'cyan'
        ]);

        Category::create([
            'name' => 'Digital Marketing',
            'slug' => 'digital-marketing',
            'color' => 'lime'
        ]);

        Category::create([
            'name' => 'E-commerce',
            'slug' => 'e-commerce',
            'color' => 'gold'
        ]);

        Category::create([
            'name' => 'Blockchain',
            'slug' => 'blockchain',
            'color' => 'violet'
        ]);

        Category::create([
            'name' => 'Game Development',
            'slug' => 'game-development',
            'color' => 'magenta'
        ]);

        Category::create([
            'name' => 'Cybersecurity',
            'slug' => 'cybersecurity',
            'color' => 'maroon'
        ]);

        Category::create([
            'name' => 'Machine Learning',
            'slug' => 'machine-learning',
            'color' => 'salmon'
        ]);

        Category::create([
            'name' => 'Web Development',
            'slug' => 'web-development',
            'color' => 'navy'
        ]);

        Category::create([
            'name' => 'SEO (Search Engine Optimization)',
            'slug' => 'seo',
            'color' => 'limegreen'
        ]);
    }
}
